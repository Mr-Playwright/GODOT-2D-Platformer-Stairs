# State.gd
extends Node
class_name State

var player: CharacterBody2D

func enter(): pass
func exit(): pass
func update():pass
func update_physics(_delta: float): pass
