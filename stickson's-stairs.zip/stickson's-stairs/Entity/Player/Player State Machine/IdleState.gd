extends State


func enter():
	print("Player is Idle")

func update_physics(delta):
	# Handle Gravity
	player.HandleGravity(delta)
	
	# Check for Transitions (The "Logic" part)
	if Input.get_axis("left", "right") != 0:
		get_parent().change_state("RunState")
		return
	
	# If we press Jump, go to Jump
	if Input.is_action_just_pressed("jump"):
		get_parent().change_state("JumpState")
		return
		
	# If we press Action, go to Action
	if Input.is_action_just_pressed("action"):
		get_parent().change_state("ActionState")
		return

	# Handle Friction. Player slows to slow down to 0 while standing still
	player.velocity.x = move_toward(player.velocity.x, 0, player.Acceleration)
	
	# Fall detection
	if not player.is_on_floor():
		get_parent().change_state("FallState")

	player.move_and_slide()
