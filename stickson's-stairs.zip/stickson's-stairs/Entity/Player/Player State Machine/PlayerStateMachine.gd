class_name PlayerStateMachine
extends Node

var current_state: Node
@export var initial_state: Node

func _ready() -> void:
	# Wait one frame to ensure the Player owner is fully ready and valid
	await owner.ready
	
	# Automatically link all child states to the player (owner)
	for state in get_children():
		state.player = owner
	
	# Start the initial state automatically
	if initial_state:
		current_state = initial_state
		current_state.enter()
	elif get_child_count() > 0:
		current_state = get_child(0)
		current_state.enter()

func change_state(new_state_name: String):
	var new_state = null
	
	for child in get_children():
		if child.name == new_state_name:
			new_state = child
			break
			
	if new_state == null:
		push_error("StateMachine Error: Could not find a state node named: " + new_state_name)
		return
		
	if current_state == new_state:
		if current_state.has_method("exit"):
			current_state.exit()
			current_state.enter()
		return

	if current_state and current_state.has_method("exit"):
		current_state.exit()
	
	current_state = new_state
	current_state.enter()
