extends State

@export var climb_speed: float = 60.0
@export var stair_visual_offset: float = 12.0 
var current_stair_direction: int = 1
var is_descending_from_top: bool = false

func enter() -> void:
	var tile_map = player.tile_map
	is_descending_from_top = false
	
	if tile_map:
		var feet_pos = player.global_position + Vector2(0, 12)
		var local_pos = tile_map.to_local(feet_pos)
		var tile_pos = tile_map.local_to_map(local_pos)
		
		if not player.is_stair_at(tile_pos):
			feet_pos = player.global_position + Vector2(player.facing * 8.0, 12)
			local_pos = tile_map.to_local(feet_pos)
			tile_pos = tile_map.local_to_map(local_pos)
			
		if not player.is_stair_at(tile_pos):
			feet_pos = player.global_position + Vector2(player.facing * 12.0, 16.0)
			local_pos = tile_map.to_local(feet_pos)
			tile_pos = tile_map.local_to_map(local_pos)
			
		if player.is_stair_at(tile_pos):
			var centered_local_pos = tile_map.map_to_local(tile_pos)
			var target_x = tile_map.to_global(centered_local_pos).x
			
			# Safety Guard: Ensure we aren't teleporting straight into a solid block wall
			player.global_position.x = target_x
		
		if player.keyDown:
			if not player.is_stair_at(tile_pos):
				is_descending_from_top = true
		else:
			player.global_position.y -= stair_visual_offset
		
		current_stair_direction = player.get_stair_direction(tile_pos)
		if current_stair_direction == 0:
			current_stair_direction = player.facing
			
		# Final overlap check: if the player body is colliding with a wall right on entry, abort to Idle
		if player.test_move(player.global_transform, Vector2.ZERO):
			get_parent().change_state("IdleState")
			return
		
	player.Sprite.position.y = 0
	player.velocity = Vector2.ZERO
	player.is_climbing = true
	print("Entered ClimbState cleanly")

func update_physics(delta: float) -> void:
	# Handle the jump off the stairs
	if Input.is_action_just_pressed("jump"):
		get_parent().change_state("JumpState")
		return
		
	# --- HANDLE ATTACK ON STAIRS ---
	if player.keyActionPressed and player.action_cooldown_timer.is_stopped():
		player.action_cooldown_timer.start()
		print("action on stairs")
		return
		
	var vertical_input := 0.0
	if player.keyUp: vertical_input -= 1.0
	if player.keyDown: vertical_input += 1.0
	
	if vertical_input != 0:
		
	# --- DESCENDING PATH ---
		if vertical_input > 0:
			# Strict validation: Only look ahead if we have a tilemap and the target tile is actually a stair
			if player.tile_map:
				var check_feet = player.global_position + Vector2(0, 16)
				var check_local = player.tile_map.to_local(check_feet)
				var check_tile = player.tile_map.local_to_map(check_local)
				
				if player.is_stair_at(check_tile):
					var actual_dir = player.get_stair_direction(check_tile)
					if actual_dir != 0:
						current_stair_direction = actual_dir

			# Dynamically adapt horizontal movement based on the stair's true slope direction
			var descent_movement = Vector2(
				-vertical_input * current_stair_direction * abs(current_stair_direction) * climb_speed,
				vertical_input * climb_speed
			) * delta
			
			if is_descending_from_top:
				player.global_position += descent_movement
				is_descending_from_top = false
				return
				
			if player.test_move(player.global_transform, descent_movement):
				get_parent().change_state("IdleState")
				return

			player.global_position += descent_movement
			
			# Correctly set facing based on active slope direction
			player.facing = -current_stair_direction
			player.Sprite.flip_h = (player.facing < 0)
			
			var descent_check_valid = player.check_is_on_stair(false, vertical_input, current_stair_direction)
			
			if not descent_check_valid:
				get_parent().change_state("IdleState")
				return
			return

		# --- ASCENDING PATH ---
		var input_dir = vertical_input 
		var movement = Vector2(
			-input_dir * current_stair_direction * climb_speed,
			input_dir * climb_speed
		) * delta

		player.global_position += movement
		player.facing = current_stair_direction
		player.Sprite.flip_h = (player.facing < 0)
		
		var next_check_valid = player.check_is_on_stair(false, vertical_input, current_stair_direction)
		
		if not next_check_valid:
			var buffer_pos = player.global_position + (movement.normalized() * 4.0)
			var local_buf = player.tile_map.to_local(buffer_pos + Vector2(0, 12))
			var tile_buf = player.tile_map.local_to_map(local_buf)
			
			if not player.is_stair_at(tile_buf):
				get_parent().change_state("IdleState")
				return

func exit() -> void:
	player.Sprite.position.y = 0
	
	if player.tile_map and (player.keyUp or player.keyDown):
		var local_pos = player.tile_map.to_local(player.global_position + Vector2(0, 12))
		var tile_pos = player.tile_map.local_to_map(local_pos)
		var top_of_tile = player.tile_map.map_to_local(tile_pos)
		
		if player.keyDown:
			var target_offset_x = -current_stair_direction * 3.0
			player.global_position.x += target_offset_x
		else:
			player.global_position.y = player.tile_map.to_global(top_of_tile).y - 12
		
	player.is_climbing = false
	player.velocity = Vector2.ZERO
	player.was_on_floor = true
	print("Exited ClimbState smoothly")
