extends State

func enter():
	
	print("Entered FallState smoothly")

func update_physics(delta):
	# 1. Apply Gravity
	player.HandleGravity(delta)
	
	# 2. Air Movement
	# You want the player to still be able to steer while falling
	var moveDirection = Input.get_axis("left", "right")
	player.ApplyHorizontalMovement(moveDirection)
	
	# 3. Transitions
	
	# Landed on floor
	if player.is_on_floor():
		if player.velocity.x == 0:
			get_parent().change_state("IdleState")
		else:
			get_parent().change_state("RunState")
		return
		
	# Attack in mid-air
	if Input.is_action_just_pressed("action"):
		get_parent().change_state("ActionState")

	# Optional: Air Jump (if your game design allows)
	# if Input.is_action_just_pressed("jump") and player.jumps < player.MaxJumps:
	#     get_parent().change_state("Jump")

	player.move_and_slide()

func exit():
	print("Entered FallState smoothly")
