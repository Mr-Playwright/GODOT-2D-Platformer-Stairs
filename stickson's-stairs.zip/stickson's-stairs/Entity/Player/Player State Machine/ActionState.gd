extends State

# Track if a brief action duration has finished while we wait for the cooldown
var action_is_done = false
var action_timer: float = 0.0
@export var action_duration: float = 0.25 # Adjust this to match how long your action should take

func enter():
	print("Entered ActionState. This does noting")
	action_is_done = false
	action_timer = action_duration
	
	# Start the cooldown timer the second the action begins!
	player.action_cooldown_timer.start()
	
	# Clear any current activity
	player.velocity.x = 0

func update_physics(delta):
	if player.is_on_floor():
		player.velocity.x = 0
	else:
		player.ApplyHorizontalMovement(player.moveDirection)
	
	player.HandleGravity(delta)
	player.move_and_slide()
	
	# Countdown the action timer
	if not action_is_done:
		action_timer -= delta
		if action_timer <= 0:
			action_is_done = true
	
	# CHECK: If the action duration is finished, BUT we are still waiting 
	# on the cooldown timer, we can safely exit the state the exact moment the timer clears!
	if action_is_done and player.action_cooldown_timer.is_stopped():
		_exit_action_state()

# A helper function to handle the actual state transition cleanly
func _exit_action_state():
	if player.is_on_floor():
		get_parent().change_state("IdleState")
	else:
		get_parent().change_state("FallState")

func exit():
	action_is_done = true
