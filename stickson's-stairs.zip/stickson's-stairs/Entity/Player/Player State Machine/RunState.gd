extends State

func enter():
	pass

func update_physics(delta):
	# 1. Apply Gravity
	player.HandleGravity(delta)
	
	# --- CLEAN STAIR ENTRY CHECK (Only from RunState) ---
	if player.is_near_stairs and Input.is_action_pressed("up"):
		get_parent().change_state("ClimbState")
		return
	# ------------------------------------
	
	# 2. Movement Logic
	var moveDirection = Input.get_axis("left", "right")
	player.ApplyHorizontalMovement(moveDirection)
	
	# 3. Transitions
	if moveDirection == 0 and abs(player.velocity.x) < 10:
		get_parent().change_state("IdleState")
		return
		
	if Input.is_action_just_pressed("jump"):
		get_parent().change_state("JumpState")
		return
		
	if Input.is_action_just_pressed("action"):
		get_parent().change_state("ActionState")
		
	if not player.is_on_floor():
		get_parent().change_state("FallState")

	player.move_and_slide()
