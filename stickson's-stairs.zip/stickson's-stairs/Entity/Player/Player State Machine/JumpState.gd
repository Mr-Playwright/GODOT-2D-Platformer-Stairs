extends State

func enter():
	player.coyote_timer.stop()
	player.velocity.y = player.JumpVelocity
	print("entered JumpState Smoothly")
	
	if not player.Animator.animation_finished.is_connected(_on_animation_finished):
		player.Animator.animation_finished.connect(_on_animation_finished)

func update_physics(delta):
	if Input.is_action_just_pressed("action"):
		get_parent().change_state("ActionState")
		return
		
	player.ApplyHorizontalMovement(player.moveDirection)
	
	# --- VARIABLE GRAVITY JUMP ---
	# If we are moving upward (velocity.y < 0) AND we are NOT holding the jump button down, 
	# multiply gravity to pull us down early. Otherwise, use normal gravity.
	var current_gravity = player.Gravity * 1.0
	if player.velocity.y < 0 and not Input.is_action_pressed("jump"):
		current_gravity = player.Gravity * 3.6 # Adjust multiplier for heavier/lighter short hop
		
	player.velocity.y += current_gravity * delta
	player.move_and_slide()
	
	if player.velocity.y > 0:
		get_parent().change_state("FallState")

func _on_animation_finished(_anim_name):
	if player.Animator.animation_finished.is_connected(_on_animation_finished):
		player.Animator.animation_finished.disconnect(_on_animation_finished)
