extends CharacterBody2D

#region Player Variables

# Nodes
@onready var Sprite = $Sprite
@onready var Animator = $Animator
@onready var Collider = $Collider
@onready var coyote_timer = $CoyoteTimer
@onready var action_cooldown_timer = $ActionCooldownTimer
@onready var hitbox_container = $Sprite/HitboxContainer
@export var state_machine: Node
@export var tile_map: TileMapLayer

@export var initial_state: State #Keep it State
# Physics Variables
const RunSpeed = 75
const Acceleration = 40
const Gravity = 300
const JumpVelocity = -175
const MaxJumps = 1

var moveSpeed = RunSpeed
var moveDirection = 0
var jumps = 0
var was_on_floor = false
var facing = 1
var was_on_floor_last_frame = false

# Stairs variables
var is_near_stairs: bool = false
var stair_tile_pos: Vector2i = Vector2i.ZERO
var is_climbing: bool = false # Kept as a reference flag if other scripts check it

# Input Variables
var keyUp = false
var keyDown = false
var keyLeft = false
var keyRight = false
var keyJump = false
var keyJumpPressed = false
var keyAction = false
var keyActionPressed = false

#endregion

func _ready():
	var list = Animator.get_animation_list()
	if list.size() > 0:
		Animator.play(list[0])

func _physics_process(delta: float) -> void:
	GetInputStates()
	
	# Check if we can mount stairs from Idle or Run
	if state_machine.current_state and state_machine.current_state.name != "ClimbState":
		if (keyUp or keyDown) and check_can_mount_stair():
			state_machine.change_state("ClimbState")
			return

	# Coyote Timer Logic
	if is_on_floor():
		coyote_timer.stop()
		was_on_floor_last_frame = true
	else:
		if was_on_floor_last_frame and velocity.y >= 0:
			coyote_timer.start()
			
		was_on_floor_last_frame = false
		
	# Access current_state through the node variable 'state_machine'
	if state_machine.current_state:
		state_machine.current_state.update_physics(delta)

func ApplyHorizontalMovement(input_dir):
	velocity.x = move_toward(velocity.x, input_dir * moveSpeed, Acceleration)

# Helper Functions (States will call these)
func HandleGravity(delta):
	if !is_on_floor():
		velocity.y += Gravity * delta
	else:
		was_on_floor = true
		jumps = 0

#region Stair Functions
func check_is_on_stair(use_offset: bool = true, vertical_input: float = 0.0, current_stair_dir: int = 1) -> bool:
	if tile_map == null:
		return false
		
	var offset_x = (facing * 8.0) if use_offset else 0.0
	var feet_pos = global_position + Vector2(offset_x, 20)
	
	if vertical_input != 0:
		# Gentle look-ahead that stays safely anchored to the current step transition
		var look_ahead_x = -sign(vertical_input) * current_stair_dir * 1.5
		var look_ahead_y = sign(vertical_input) * 1.5
		feet_pos += Vector2(look_ahead_x, look_ahead_y)
	
	var local_pos = tile_map.to_local(feet_pos)
	var tile_pos = tile_map.local_to_map(local_pos)
	
	if is_stair_at(tile_pos):
		return true
		
	if is_stair_at(tile_map.local_to_map(tile_map.to_local(feet_pos + Vector2(6, 0)))):
		return true
	if is_stair_at(tile_map.local_to_map(tile_map.to_local(feet_pos + Vector2(-6, 0)))):
		return true
		
	return false

func is_stair_at(tile_pos: Vector2i) -> bool:
	if not tile_map:
		return false
	
	var tile_data = tile_map.get_cell_tile_data(tile_pos)
	if not tile_data:
		return false
		
	# First check: Ensure the tile has the "is_stair" custom data set to true
	if tile_data.get_custom_data("is_stair") != true:
		return false
		
	# Second check: Ensure it has a valid "stair_direction" defined before proceeding
	var dir = tile_data.get_custom_data("stair_direction")
	return dir != null and dir != 0

func get_stair_direction(tile_pos: Vector2i) -> int:
	var tile_data = tile_map.get_cell_tile_data(tile_pos)
	if tile_data:
		return tile_data.get_custom_data("stair_direction")
	return 1 # Default fallback to right-facing

func check_can_mount_stair() -> bool:
	if tile_map == null:
		return false
		
	var feet_pos = global_position + Vector2(0, 12)
	var local_pos = tile_map.to_local(feet_pos)
	var tile_pos = tile_map.local_to_map(local_pos)
	
	if not is_stair_at(tile_pos):
		return false
		
	# If the player is on the ground and pressing down, check if we're at the bottom of the stairs
	if is_on_floor() and (Input.is_action_pressed("down")):
		var tile_below = tile_pos + Vector2i(0, 1)
		# If there is no stair below us, we are already at the bottom edge—do not enter climb state
		if not is_stair_at(tile_below):
			return false

	# Allow top-down entry if pressing down
	if Input.is_action_pressed("down"):
		return true
		
	# Otherwise, ensure facing direction matches for bottom-up mounting
	var stair_dir = get_stair_direction(tile_pos)
	if stair_dir != 0 and facing != stair_dir:
		return false
		
	return true

#endregion

func GetInputStates():
	keyUp = Input.is_action_pressed("up")
	keyDown = Input.is_action_pressed("down")
	keyLeft = Input.is_action_pressed("left")
	keyRight = Input.is_action_pressed("right")
	keyJump = Input.is_action_pressed("jump")
	keyJumpPressed = Input.is_action_just_pressed("jump")
	keyAction = Input.is_action_pressed("action")
	keyActionPressed = Input.is_action_just_pressed("action")
	moveDirection = Input.get_axis("left", "right")
		
	# Entering ActionState
	if keyActionPressed:
		var current_state_name = state_machine.current_state.name if state_machine.current_state else ""
		if current_state_name != "ClimbState" and action_cooldown_timer.is_stopped():
			state_machine.change_state("ActionState")
		
	# Entering JumpState
	if keyJumpPressed:
		if is_on_floor() or not coyote_timer.is_stopped():
			state_machine.change_state("JumpState")
	
	if (moveDirection != 0):
		facing = sign(moveDirection)
	Sprite.flip_h = (facing < 0)
	$Sprite/HitboxContainer.scale.x = facing
